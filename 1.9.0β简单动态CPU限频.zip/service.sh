MODDIR=${0%/*}
function wait_until_boot() {
	while [ "$(getprop sys.boot_completed)" != '1' ]; do
		sleep 20
	done
}

function env_init(){
    chmod 644 /sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq
    chmod 644 /sys/devices/system/cpu/cpu4/cpufreq/scaling_max_freq
    chmod 644 /sys/devices/system/cpu/cpu7/cpufreq/scaling_max_freq
    
    chmod 644 /dev/cpuset/background/cpus
    chmod 644 /dev/cpuset/system-background/cpus
    
    # chmod 644 /sys/class/kgsl/kgsl-3d0/max_pwrlevel
    return 0
}
function env_reset(){
    chmod 444 /sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq
    chmod 444 /sys/devices/system/cpu/cpu4/cpufreq/scaling_max_freq
    chmod 444 /sys/devices/system/cpu/cpu7/cpufreq/scaling_max_freq
    # chmod 444 /sys/class/kgsl/kgsl-3d0/max_pwrlevel
    return 0
}
function set_cpus(){
	echo "0-6" > /dev/cpuset/background/cpus
	echo "0-6" > /dev/cpuset/system-background/cpus
	return 0
}

wait_until_boot
sleep 90
env_init 
set_cpus

init_code=0
# touch $MODDIR/code_record.log
while :
do
	nohup sh $MODDIR/CPU_Limit.sh $init_code > $MODDIR/cur_stat.log 2>&1
	init_code=$?
	# echo "[$(date "+%H:%M:%S")]" $init_code >> $MODDIR/code_record.log
	sleep 5
done