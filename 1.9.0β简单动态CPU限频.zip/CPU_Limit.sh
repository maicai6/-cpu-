MODDIR=${0%/*}

function freq_change(){
    # Set CPU0 scaling_max_freq
    echo "$1" > /sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq
    
    # Set CPU4 scaling_max_freq
    echo "$2" > /sys/devices/system/cpu/cpu4/cpufreq/scaling_max_freq
    
    # Set CPU7 scaling_max_freq
    echo "$3" > /sys/devices/system/cpu/cpu7/cpufreq/scaling_max_freq
    
    # Set kgsl-3d0 max_pwrlevel
    #echo "$4" > /sys/class/kgsl/kgsl-3d0/max_pwrlevel
    return 0
}

function limit_freq(){
	freq_change 1555200 2054400 2092800
}

function recover_freq(){
	freq_change 2016000 2803200 3187200
}

# Start Check
init_code=$1
if [[ $1 -eq 0 ]]; then
	echo ">> Script start by Daily Mode"
	limit_freq
	flag="do_freezer_trap"
	init_code=3
elif [[ $1 -eq 3 ]]; then
	echo ">> Daily Mode"
	# CPU_Limit 902400 1651200 1708800 4
	flag="do_freezer_trap"
elif [[ $1 -eq 4 ]]; then
	echo ">> Game Mode"
	# CPU_Limit 2016000 2803200 3187200 0
	flag="__arm64_sys_epoll_pwait"
else
	echo ">> Unknown error occurred, recover by Daily Mode"
	limit_freq
	flag="do_freezer_trap"
fi
sleep 30

# Listening Mission
for counter in 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3
do
	sleep_time=$((60 * $counter + 10))
	status=`ps -A | grep oplus.games | awk '{print $6}'`
	# echo $status ps -A | grep oplus.games
	
	if [[ "$status" == '' ]]; then
		status="do_freezer_trap"
	fi
	
	if [[ "$status" == "$flag" ]]; then
		echo "[$(date "+%H:%M:%S")]" "No change, sleep_time:" $sleep_time
		sleep $sleep_time
		continue
	fi

	if [[ "$status" == "do_freezer_trap" ]]; then
		# echo ">> Daily Mode"
		limit_freq
		exit 3
	elif [[ "$status" == "__arm64_sys_epoll_pwait" ]]; then
		# echo ">> Game Mode"
		sleep 10
		# Game Check Again
		status=`ps -A | grep oplus.games | awk '{print $6}'`
		if [[ "$status" == "__arm64_sys_epoll_pwait" ]]; then
			recover_freq
			exit 4
		else
			echo "[$(date "+%H:%M:%S")]" "No change, sleep_time:" $sleep_time
			sleep $sleep_time
		fi
	fi
done
exit $init_code